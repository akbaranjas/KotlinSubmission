package com.akbaranjas.footballmatchschedule.adapter

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentPagerAdapter
import com.akbaranjas.footballmatchschedule.fragment.LastMatchFragment
import com.akbaranjas.footballmatchschedule.fragment.NextMatchFragment

class MainFragmentAdapter(fm : FragmentManager) : FragmentPagerAdapter(fm){
    private val pages = listOf(
        LastMatchFragment(),
        NextMatchFragment()
    )
    override fun getItem(position: Int): Fragment {
        return pages[position] as Fragment
    }

    override fun getCount(): Int {
        return pages.size
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return when(position){
            0 -> "Last Match"
            1 -> "Next Match"
            else -> ""
        }
    }

}